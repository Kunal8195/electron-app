Virtual Env setup

pip install virtualenv  
cd my_project_folder  
virtualenv my_project  
source my_project/bin/activate



Set the environment variables for Linux (Ubuntu) 

# On Linux / OS X:

# env
export npm_config_target=1.4.15 # electron version  
export npm_config_runtime=electron  
export npm_config_disturl=https://atom.io/download/electron  
export npm_config_build_from_source=true  




1. npm install

2. ./node_modules/.bin/electron .
